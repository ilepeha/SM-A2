import time
import json
from collections import defaultdict
from selenium import webdriver
from selenium.webdriver.chrome.service import Service


def collect_performance_data(url, iterations=10):
    """
    Collects performance data for a URL over multiple iterations.

    Args:
        url (str): The URL to measure.
        iterations (int): Number of iterations for measurement.

    Returns:
        tuple: Raw performance data for each iteration, average performance data.
    """
    # Configure Selenium WebDriver
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')  # Optional: Run in headless mode
    options.add_argument('--disable-cache')  # Disable caching

    # Set up WebDriver with your specific path
    service = Service('/opt/homebrew/bin/chromedriver')  # Your ChromeDriver path
    driver = webdriver.Chrome(service=service, options=options)

    # Dictionary to store raw performance data
    raw_results = defaultdict(list)

    for iteration in range(iterations):
        print(f"Iteration {iteration + 1}: Measuring performance for {url}")
        driver.get(url)

        # Wait for the page to fully load
        time.sleep(2)

        # Execute JavaScript to fetch performance entries
        performance_entries = driver.execute_script("return window.performance.getEntries();")

        # Collect data for each resource
        for entry in performance_entries:
            name = entry.get("name", "unknown")
            duration = entry.get("duration", 0)
            raw_results[name].append(duration)

        # Clear browser cache to avoid caching effects
        driver.delete_all_cookies()

    driver.quit()

    # Compute average performance data
    average_results = {
        name: {
            "average": sum(durations) / len(durations),
            "min": min(durations),
            "max": max(durations)
        }
        for name, durations in raw_results.items()
    }

    return raw_results, average_results


def save_to_json(data, filename):
    """
    Saves data to a JSON file.

    Args:
        data (dict): The data to save.
        filename (str): The filename for the JSON file.
    """
    with open(filename, "w") as f:
        json.dump(data, f, indent=2)
    print(f"Data saved to {filename}")


def save_to_csv(data, filename):
    """
    Saves data to a CSV file.

    Args:
        data (dict): The data to save.
        filename (str): The filename for the CSV file.
    """
    import csv
    with open(filename, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Name", "Duration"])
        for name, durations in data.items():
            for duration in durations:
                writer.writerow([name, duration])
    print(f"Data saved to {filename}")


def save_averages_to_csv(averages, filename):
    """
    Saves average performance data to a CSV file.

    Args:
        averages (dict): The average performance data.
        filename (str): The filename for the CSV file.
    """
    import csv
    with open(filename, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Name", "Average Duration", "Min Duration", "Max Duration"])
        for name, metrics in averages.items():
            writer.writerow([name, metrics["average"], metrics["min"], metrics["max"]])
    print(f"Averages saved to {filename}")


if __name__ == "__main__":
    # URL to measure
    url = "https://en.wikipedia.org/wiki/Software_metric"

    # Collect performance data
    raw_data, average_data = collect_performance_data(url)

    # Save raw data and averages to JSON
    save_to_json(raw_data, "performance.json")
    save_to_json(average_data, "average_performance.json")

    # Save raw data and averages to CSV
    save_to_csv(raw_data, "performance.csv")
    save_averages_to_csv(average_data, "average_performance.csv")

    print("Performance measurement completed successfully!")
