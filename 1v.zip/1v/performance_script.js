const { Builder } = require('selenium-webdriver');
const fs = require('fs');

(async function measurePerformance() {
    const driver = new Builder().forBrowser('chrome').build();
    const performanceRecords = [];

    try {
        for (let i = 0; i < 10; i++) {
            console.log(`Iteration ${i + 1}: Collecting performance data...`);
            await driver.get('https://en.wikipedia.org/wiki/Software_metric');

            const performanceData = await driver.executeScript(() => {
                return JSON.stringify(window.performance.toJSON());
            });

            const parsedData = JSON.parse(performanceData).timing;
            performanceRecords.push(parsedData);
        }

        // Save the performance data
        fs.writeFileSync('performance.json', JSON.stringify(performanceRecords, null, 2), 'utf-8');
        console.log('Performance data saved to performance.json');

        // Calculate averages
        const averages = {};
        performanceRecords.forEach(record => {
            Object.entries(record).forEach(([key, value]) => {
                averages[key] = (averages[key] || 0) + value / performanceRecords.length;
            });
        });

        // Save averages
        fs.writeFileSync('average_performance.json', JSON.stringify(averages, null, 2), 'utf-8');
        console.log('Average performance data saved to average_performance.json');
    } finally {
        await driver.quit();
    }
})();
