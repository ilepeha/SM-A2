const fs = require('fs');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

(async function parseJsonToCsv() {
    // Read performance data
    const performanceData = JSON.parse(fs.readFileSync('performance.json', 'utf-8'));
    const averageData = JSON.parse(fs.readFileSync('average_performance.json', 'utf-8'));

    // Prepare performance data for CSV
    const performanceCsvData = performanceData.flatMap((record, index) => {
        return Object.entries(record).map(([key, value]) => ({
            name: `${key} (Run ${index + 1})`,
            duration: value
        }));
    });

    // Write performance data to CSV
    const performanceCsvWriter = createCsvWriter({
        path: 'performance.csv',
        header: [
            { id: 'name', title: 'Name' },
            { id: 'duration', title: 'Duration' }
        ]
    });

    await performanceCsvWriter.writeRecords(performanceCsvData);
    console.log('Performance data saved to performance.csv');

    // Prepare average data for CSV
    const averageCsvData = Object.entries(averageData).map(([key, value]) => ({
        name: key,
        duration: value
    }));

    // Write average data to CSV
    const averageCsvWriter = createCsvWriter({
        path: 'average_performance.csv',
        header: [
            { id: 'name', title: 'Name' },
            { id: 'duration', title: 'Average Duration' }
        ]
    });

    await averageCsvWriter.writeRecords(averageCsvData);
    console.log('Averages saved to average_performance.csv');
})();
